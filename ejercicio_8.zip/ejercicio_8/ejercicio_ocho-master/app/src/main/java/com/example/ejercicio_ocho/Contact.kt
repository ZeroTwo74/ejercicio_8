package com.example.ejercicio_ocho

data class Contact (val name: String, val phoneNumber: String)
