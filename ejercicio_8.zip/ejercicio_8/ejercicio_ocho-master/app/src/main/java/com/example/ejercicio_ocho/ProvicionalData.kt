package com.example.ejercicio_ocho

class ProvicionalData {
    companion object{
        val listContact = ArrayList<Contact>()
    }
}